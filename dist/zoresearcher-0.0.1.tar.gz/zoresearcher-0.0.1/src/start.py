print("START")
import os
os.chdir(r"C:\Users\dlwal\Dropbox\zoresearcher\src\zoresearcher")

import zoresearcher
zoresearcher.open(r"C:\\Users\\dlwal\\Zotero")

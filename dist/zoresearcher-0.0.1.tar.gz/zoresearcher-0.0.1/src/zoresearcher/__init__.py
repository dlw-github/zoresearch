invocation = f'Invoking __init__.py for {__name__}'

print(invocation)

from zoresearcher.main import open
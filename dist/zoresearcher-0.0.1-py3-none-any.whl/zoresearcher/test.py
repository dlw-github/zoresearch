my_list = []

name = ' '.join(my_list).strip()


if not name:
	print('empy')
print(name)